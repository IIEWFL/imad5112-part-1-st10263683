package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private var number1: TextView? = null
    private var number2: TextView? = null
    private var answer: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        number1 = findViewById(R.id.number1)
        number2 = findViewById(R.id.number2)
        answer = findViewById(R.id.tvAnswer)



        val number1 = findViewById<EditText>(R.id.number1)
        val number2 = findViewById<EditText>(R.id.number2)
        val answer = findViewById<TextView>(R.id.tvAnswer)
        val buttonAdd = findViewById<Button>(R.id.buttonAdd)
        val buttonSub = findViewById<Button>(R.id.buttonSub)
        val buttonMul = findViewById<Button>(R.id.buttonMul)
        val buttonDivide = findViewById<Button>(R.id.buttonDivide)
        val buttonSqrt = findViewById<Button>(R.id.buttonSqrt)
        val buttonPower = findViewById<Button>(R.id.buttonPower)
        val buttonStats = findViewById<Button>(R.id.buttonStats)

        buttonAdd.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val num2 = number2.text.toString().toDouble()
            val result = num1 + num2
            answer.text = result.toString()
        }

        buttonSub.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val num2 = number2.text.toString().toDouble()
            val result = num1 - num2
            answer.text = result.toString()
        }

        buttonMul.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val num2 = number2.text.toString().toDouble()
            val result = num1 * num2
            answer.text = result.toString()
        }

        buttonDivide.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val num2 = number2.text.toString().toDouble()
            if (num2 != 0.0) {
                val result = num1 / num2
                answer.text = result.toString()
            } else {
                answer.text = "Cannot divide by zero"
            }
        }

        buttonSqrt.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val result = Math.sqrt(num1)
            answer.text = result.toString()
        }

        buttonPower.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val num2 = number2.text.toString().toDouble()
            val result = Math.pow(num1, num2)
            answer.text = result.toString()
        }

        buttonStats.setOnClickListener {
            buttonStats.setOnClickListener {
                val numbers = mutableListOf<Double>()
                val inputNumbers = number1.text.toString().split(" ")

                for (numStr in inputNumbers) {
                    val num = numStr.toDoubleOrNull()
                    if (num != null) {
                        numbers.add(num)
                    }
                }

                if (numbers.isEmpty()) {
                    answer.text = "No valid numbers entered"
                    return@setOnClickListener
                }

                val mean = numbers.average()

                val squaredDiffs = numbers.map { (it - mean) * (it - mean) }
                val variance = squaredDiffs.sum() / numbers.size

                val stdDeviation = Math.sqrt(variance)

                answer.text = "Mean: $mean\nStandard Deviation: $stdDeviation"
            }
        }

    }
}

